<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Password Reset</title>
</head>
<body>

  <p>Hi there! It looks like you requested a temporary password.</p>
  <br/>
  <p>Your New Password is {{$password}}</p>
  <p>Please be sure to update your password in your account settings.</p>
</body>
</html>
