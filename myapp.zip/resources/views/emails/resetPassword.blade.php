<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Booking</title>
</head>
<style>

</style>
<body>
    <p>Here is the temporary password you requested.</p>
    <strong>Make sure you update your password after logging in</strong>
    <p>Temporary Password: {{$temp}}</p>
</body>
</html>
