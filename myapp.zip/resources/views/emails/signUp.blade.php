<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Welcome to the Mesh Network</title>
</head>
<body>

  <p>Hi there! We'd like to welcome you to the Mesh Network.</p>
  <br/>
  <p>Please enjoy working at our Collaborative Workspaces and the features of the Mesh Network.</p>
</body>
</html>
