<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Userskill extends Model
{

}
