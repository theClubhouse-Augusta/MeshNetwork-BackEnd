<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Eventskill extends Model
{
    //
}
