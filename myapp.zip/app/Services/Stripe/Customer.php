<?php 
namespace App\Services\Stripe;

use Stripe\Customer as StripeCustomer;

// class Customer {
//     public function __construct($customer_id) {
//         StripeCustomer::
//     }
// }