<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ptbind extends Model
{
    //
}
