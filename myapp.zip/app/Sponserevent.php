<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sponserevent extends Model
{
    //
}
