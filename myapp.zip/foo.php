<?php
 echo intval("") == 0;
?>
